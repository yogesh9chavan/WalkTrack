package com.example.svbhargav.sosalert;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.provider.Settings;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SurfaceHolder;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends ActionBarActivity {

    String phoneNumber = "5556";
    double distance=0;
    Button btnSendSMS;
    Button btnGetLocation;
    TextView txtLocation;

    private String defaultMessage = "Your device is out of range!!!!";

    Location location = null;
    LocationManager locationManager;
    double latitude, longitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSendSMS = (Button) findViewById(R.id.btnSendSMS);
        btnGetLocation = (Button) findViewById(R.id.btnGetLocation);
        txtLocation = (TextView) findViewById(R.id.txtLocation);

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, new myLocationListener());

        btnSendSMS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // if(distance>500)
                sendSMS();
            }
        });

        btnGetLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                checkGPS();
//                getLocation();
                showLocation();
            }
        });

    }

    private void showLocation() {
        location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        if (location != null) {
            latitude = location.getLatitude();
            longitude = location.getLongitude();
            txtLocation.setText("Location: "+latitude+" & "+longitude);
        }
        else {
            txtLocation.setText("Unable to get the location. Check your GPS");
        }
    }

    /*
    private void checkGPS() {
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if(!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            final AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setMessage("Your GPS seems to be disabled, do you want to enable it ?")
                    .setCancelable(false)
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            Intent openSettings = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);

                            startActivityForResult(openSettings, 0);
                        }
                    })
                    .setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });
            final AlertDialog alertDialog = builder.create();

            alertDialog.show();
        }

    }
    */

    private void getLocation() {
        Toast.makeText(getBaseContext(), "getLocation", Toast.LENGTH_SHORT).show();

        if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            Toast.makeText(getBaseContext(), "Entered IF loop", Toast.LENGTH_SHORT).show();
            locationManager = (LocationManager) getSystemService(getApplicationContext().LOCATION_SERVICE);
            location = locationManager.getLastKnownLocation(locationManager.getBestProvider(new Criteria(), true));
            Toast.makeText(getBaseContext(), "Location: "+location, Toast.LENGTH_SHORT).show();
            if (location != null) {
                Toast.makeText(getBaseContext(), "Entered IF LOCATION loop", Toast.LENGTH_SHORT).show();
                latitude = location.getLatitude();
                longitude = location.getLongitude();
                txtLocation.setText("Location: "+latitude+longitude);
                Location locationFixed = new Location("Point A");
                locationFixed.setLatitude(39.767854);
                locationFixed.setLongitude(-84.056246);
                distance = locationFixed.distanceTo(location);
            }
        }
        else {
            Toast.makeText(getBaseContext(), "Entered ELSE loop", Toast.LENGTH_SHORT).show();
            txtLocation.setText("Enable the GPS Services");
        }
    }

    private void sendSMS() {

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, defaultMessage, null, null);
            Toast.makeText(getApplicationContext(), "SMS sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "Failed to send SMS", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

    }

    private class myLocationListener implements LocationListener {
        @Override
        public void onLocationChanged(Location location) {
            Toast.makeText(getBaseContext(), "Location changed", Toast.LENGTH_SHORT).show();
            latitude = location.getLatitude();
            longitude = location.getLongitude();
            txtLocation.setText("Location: "+latitude+" & "+longitude);
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
            Toast.makeText(getBaseContext(), "Provider changed", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onProviderEnabled(String provider) {
            Toast.makeText(getBaseContext(), "GPS turned on", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onProviderDisabled(String provider) {
            Toast.makeText(getBaseContext(), "GPS turned off", Toast.LENGTH_SHORT).show();
        }
    }
}